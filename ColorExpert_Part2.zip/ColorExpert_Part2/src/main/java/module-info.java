module com.example.colourexpert {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.colourexpert to javafx.fxml;
    exports com.example.colourexpert;
}