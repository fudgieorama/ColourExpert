package com.example.colourexpert;

import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;

import java.util.ArrayList;
import java.util.Random;

public class ShapeBox<T extends Shape> {
    private int marker;
    private ArrayList<Shape> shapes = new ArrayList<>();

    // Colors
    private int r;
    private int g;
    private int b;
    private int redCounter;
    private int greenCounter;
    private int blueCounter;

    private Random rand;

    public int getMarker() {
        return marker;
    }

    public void constructBox(T shape, int n) {

    }

    public Shape constructShape(T shape, int r, int g, int b) {

        if (shape instanceof Circle) {
            Circle circle = new Circle(5);
            Color c = Color.rgb(r,g,b);
            circle.setFill(c);
            return circle;
        } else if (shape instanceof Rectangle) {
            Rectangle rect = new Rectangle(1,1);
            return rect;
        } else {
            return null;
        }

    }

}
